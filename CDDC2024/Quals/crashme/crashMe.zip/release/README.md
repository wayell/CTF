# crashMe

## Usage

```bash
./build.sh
./run.sh

nc localhost 19754
```
